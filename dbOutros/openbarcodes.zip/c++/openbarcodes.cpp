// V 2.0.0

// Copyright (C) 2006 (Grandzebu)

// Cette biblioth�que est  libre, vous pouvez la redistribuer et/ou la modifier
// selon les termes de la Licence Publique G�n�rale Amoindrie GNU (GNU LGPL)
// Veuillez charger une copie de la license � l'adresse : http://www.gnu.org/licenses/lgpl.html
// Une traduction non officielle se trouve � l'adresse : http://www.linux-france.org/article/these/licence/lgpl/lgpl_monoblock.html

// This library is free, you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public License (GNU LGPL)
// Please download a license copy at : http://www.gnu.org/licenses/lgpl.html

long __stdcall Code39(char *BufIn, long SizeIn, unsigned char *BufOut) {
  int i;
  char x;
  if (SizeIn > 0) {
    *BufOut = (char) '*';
    for (i = 0; i < SizeIn; i++) {
      x = *(BufIn + i);
      //V�rifier si caract�res valides
      //Check for valid characters
      if (x != 32 && x != 36 && x != 37 && x != 43 && (x < 45 || x > 57) && (x < 65 || x > 90)) return 1;
	    *(BufOut + i + 1) = x;
    }
    *(BufOut + i + 1) = (char) '*';
	} else {
	  return 1;
	}
  return 0;
}

long __stdcall Ean13(char *BufIn, unsigned char *BufOut) {
  int i;
  char x;
  long checksum;
  bool tableA;
  //V�rifier qu'il y a 12 caract�res
  //Check for 12 characters
  //Et que ce sont bien des chiffres
  //And they are really digits
  for (i = 0; i < 12; i++) {
    x = *(BufIn + i);
    if (x < 48 || x > 57) return 1;
  }
  //Calcul de la cl� de contr�le
  //Calculation of the checksum
  checksum = 0;
  for (i = 11; i >= 0; i = i - 2) checksum = checksum + *(BufIn + i) - 48;
  checksum = checksum * 3;
  for (i = 10; i >= 0; i = i - 2) checksum = checksum + *(BufIn + i) - 48;
  checksum = (10 - checksum % 10) % 10;
  //Le premier chiffre est pris tel quel, le deuxi�me vient de la table A
  //The first digit is taken just as it is, the second one come from table A
  *BufOut = *BufIn;
  *(BufOut + 1) = *(BufIn + 1) + 17;
  for (i = 2; i <= 6; i++) {
    tableA = false;
    switch (i) {
    case 2:
      if (*BufIn > 47 && *BufIn < 52) tableA = true;
      break;
    case 3:
      if (*BufIn == 48 || *BufIn == 52 || *BufIn == 55 || *BufIn == 56) tableA = true;
      break;
    case 4:
      if (*BufIn == 48 || *BufIn == 49 || *BufIn == 52 || *BufIn == 53 || *BufIn == 57) tableA = true;
      break;
    case 5:
      if (*BufIn == 48 || *BufIn == 50 || *BufIn == 53 || *BufIn == 54 || *BufIn == 55) tableA = true;
      break;
    case 6:
      if (*BufIn == 48 || *BufIn == 51 || *BufIn == 54 || *BufIn == 56 || *BufIn == 57) tableA = true;
    }
    if (tableA) {
      *(BufOut + i) = *(BufIn + i) + 17;
    } else {
      *(BufOut + i) = *(BufIn + i) + 27;
    }
  }
  *(BufOut + 7) = (char) '*'; //Ajout s�parateur central / Add middle separator
  for (i = 7; i <= 11; i++) *(BufOut + i + 1) = *(BufIn + i) + 49;
  *(BufOut + 13) = checksum + 97;
  *(BufOut + 14) = (char) '+'; //Ajout de la marque de fin / Add end mark
  return 0;
}

long __stdcall Ean8(char *BufIn, unsigned char *BufOut) {
  int i;
  char x;
  long checksum;
  //V�rifier qu'il y a 7 caract�res
  //Check for 7 characters
  //Et que ce sont bien des chiffres
  //And they are really digits
  for (i = 0; i < 7; i++) {
    x = *(BufIn + i);
    if (x < 48 || x > 57) return 1;
  }
  //Calcul de la cl� de contr�le
  //Calculation of the checksum
  checksum = 0;
  for (i = 6; i >= 0; i = i - 2) checksum = checksum + *(BufIn + i) - 48;
  checksum = checksum * 3;
  for (i = 5; i >= 0; i = i - 2) checksum = checksum + *(BufIn + i) - 48;
  checksum = (10 - checksum % 10) % 10;
  *(BufOut) = (char) ':'; //Ajout marque de d�but / Add start mark
  //Les 4 premier chiffre viennent de la table A
  //The first 4 digits come from table A
  for (i = 0; i <= 3; i++) *(BufOut + i + 1) = *(BufIn + i) + 17;
  *(BufOut + 5) = (char) '*'; //Ajout s�parateur central / Add middle separator
  for (i = 4; i <= 6; i++) *(BufOut + i + 2) = *(BufIn + i) + 49;
  *(BufOut + 9) = checksum + 97;
  *(BufOut + 10) = (char) '+'; //Ajout de la marque de fin / Add end mark
  return 0;
}

long __stdcall AddOn(char *BufIn, long SizeIn, unsigned char *BufOut) {
  int i;
  char x;
  long checksum;
  bool tableA;
  //V�rifier qu'il y a 2 ou 5 caract�res
  //Check for 2 or 5 characters
  if (SizeIn == 2 || SizeIn == 5) {
    //Et que ce sont bien des chiffres
    //And they are really digits
    for (i = 0; i < SizeIn; i++) {
      x = *(BufIn + i);
      if (x < 48 || x > 57) return 1;
    }
    //Calcul de la cl� de contr�le
    //Calculation of the checksum
    if (SizeIn == 2) {
      checksum = 10 + ((*BufIn - 48) * 10 + *(BufIn + 1) - 48) % 4; //On augmente la checksum de 10 pour faciliter les tests plus bas / We add 10 to the checksum for make easier the below tests
    } else {
      checksum = 0;
      for (i = 4; i >= 0; i = i - 2) checksum = checksum + *(BufIn + i) - 48;
      checksum = checksum * 3;
      for (i = 3; i >= 0; i = i - 2) checksum = checksum + (*(BufIn + i) - 48) * 9;
      checksum = checksum % 10;
    }
    *(BufOut) = (char) '['; //Ajout s�parateur / Add separator
    for (i = 0; i < SizeIn; i++) {
      tableA = false;
      switch (i) {
      case 0:
        if (checksum > 3) tableA = true;
        break;
      case 1:
        if (checksum == 1 || checksum == 2 || checksum == 3 || checksum == 5 || checksum == 6 || checksum == 9 || checksum == 10 || checksum == 12) tableA = true;
        break;
      case 2:
        if (checksum == 0 || checksum == 2 || checksum == 3 || checksum == 6 || checksum == 7 || checksum == 8) tableA = true;
        break;
      case 3:
        if (checksum == 0 || checksum == 1 || checksum == 3 || checksum == 4 || checksum == 8 || checksum == 9) tableA = true;
        break;
      case 4:
        if (checksum == 0 || checksum == 1 || checksum == 2 || checksum == 4 || checksum == 5 || checksum == 7) tableA = true;
      }
      if (tableA) {
        *(BufOut + i * 2 + 1) = *(BufIn + i) + 17;
      } else {
        *(BufOut + i * 2 + 1) = *(BufIn + i) + 27;
      }
      if ((SizeIn == 2 && i == 0) || (SizeIn == 5 && i < 4)) *(BufOut + i * 2 + 2) = 92; //Ajout du s�parateur de caract�re / Add character separator
    }
	} else {
	  return 1;
	}
  return 0;
}

long __stdcall Code25I(char *BufIn, long SizeIn, bool *Key, unsigned char *BufOut) {
  int i;
  char x;
  long checksum;
  long dummy;
  if (SizeIn > 0) {
    //V�rifier si caract�res valides
    //Check for valid characters
    for (i = 0; i < SizeIn; i++) {
      x = *(BufIn + i);
      if (x < 48 || x > 57) return 1;
    }
    //Ajouter si n�cessaire la cl�
    //Add if necessary the checksum
    x = 0;
    if (Key) {
      checksum = 0;
      for (i = SizeIn - 1; i >= 0; i = i - 2) checksum = checksum + *(BufIn + i) - 48;
      checksum = checksum * 3;
      for (i = SizeIn - 2; i >= 0; i = i - 2) checksum = checksum + *(BufIn + i) - 48;
      checksum = (10 - checksum % 10) % 10;
      x = 1;
    }
    //V�rifier si la longueur est paire
    //Check if the length is odd
    if ((SizeIn + x) % 2 != 0) return 1;
    //Calculer la chaine de code
    //Calculation of the code string
    *BufOut = 201; //Start
    for (i = 0; i < SizeIn; i = i + 2) {
      dummy = (*(BufIn + i) - 48) * 10 + *(BufIn + i + 1) - 48;
      *(BufOut + i / 2 + 1) = (dummy < 94) ? dummy + 33 : dummy + 101;
    }
    //S'il y a une cl�, l'attacher au dernier chiffre
    // If there is a key, attach it to the last digit
    if (x == 1) {
      dummy = (*(BufIn + SizeIn - 1) - 48) * 10 + checksum;
      *(BufOut + SizeIn / 2 + 1) = (dummy < 94) ? dummy + 33 : dummy + 101;
    }
    *(BufOut + SizeIn / 2 + x + 1) = 202; //Stop
  } else {
	  return 1;
	}
  return 0;
}

long __stdcall Code128(char *BufIn, long SizeIn, long *SizeOut, unsigned char *BufOut) {
  int i;
  long j;
  char x;
  int checksum;
  long mini;
  long dummy;
  bool tableB;
  if (SizeIn > 0) {
    //V�rifier si caract�res valides
    //Check for valid characters
    for (i = 0; i < SizeIn; i++) {
      x = *(BufIn + i);
      if ((x < 32 || x > 126) && x != 203) return 1;
    }
    //Calculer la chaine de code en optimisant l'usage des tables B et C
    //Calculation of the code string with optimized use of tables B and C
    tableB = true;
    i = 0; //i devient l'index sur la chaine d'entr�e / i become the input string index
    j = 0; //j est l'index sur la chaine de sortie / j is the output string index
    while (i < SizeIn) {
      if (tableB) {
        //Voir si int�ressant de passer en table C / See if interesting to switch to table C
        //Oui pour 4 chiffres au d�but ou � la fin, sinon pour 6 chiffres / yes for 4 digits at start or end, else if 6 digits
        mini = (i == 0 || i + 4 == SizeIn) ? 3 : 5;
        if (i + mini < SizeIn) {
          while (mini >= 0) {
            if (*(BufIn + i + mini) < 48 || *(BufIn + i + mini) > 57) break;
            mini--;
          }
        }
        //si les mini% caract�res � partir de i% sont num�riques, alors mini%=-1
        //if the mini% characters from i% are numeric, then mini%=-1
        if (mini < 0) { //Choix table C / Choice of table C
          if (i == 0) { //D�buter sur table C / Starting with table C
            if (j < *SizeOut) *(BufOut + j) = 210;
          } else { //Commuter sur table C / Switch to table C
            if (j < *SizeOut) *(BufOut + j) = 204;
          }
          j++;
          tableB = false;
        } else {
          if (i == 0) {
            if (j < *SizeOut) *(BufOut + j) = 209; //D�buter sur table B / Starting with table B
            j++;
          }
        }
      }
      if (! tableB) {
        //On est sur la table C, essayer de traiter 2 chiffres / We are on table C, try to process 2 digits
        mini = 1;
        if (i + mini < SizeIn) {
          while (mini >= 0) {
            if (*(BufIn + i + mini) < 48 || *(BufIn + i + mini) > 57) break;
            mini--;
          }
        }
        //si les mini% caract�res � partir de i% sont num�riques, alors mini%=-1
        //if the mini% characters from i% are numeric, then mini%=-1
        if (mini < 0) { //OK pour 2 chiffres, les traiter / OK for 2 digits, process it
          dummy =  (*(BufIn + i) - 48) * 10 + *(BufIn + i + 1) - 48;
          if (j < *SizeOut) *(BufOut + j) = (dummy < 95) ? dummy + 32 : dummy + 105;
          i = i + 2;
        } else { //On n'a pas 2 chiffres, repasser en table B / We haven't 2 digits, switch to table B
          if (j < *SizeOut) *(BufOut + j) = 205;
          tableB = true;
        }
        j++;
      }
      if (tableB) {
        //Traiter 1 caract�re en table B / Process 1 digit with table B     
        if (j < *SizeOut) *(BufOut + j) = *(BufIn + i);
        j++;
        i++;
      }
    }
    //Calcul de la cl� de contr�le / Calculation of the checksum
    for (i = 0; i < j; i++) {
      dummy = *(BufOut + i);
      dummy = (dummy < 127) ? dummy - 32 : dummy - 105;
      if (i == 0) checksum = dummy;
      checksum = (checksum + i * dummy) % 103;
    }
    //Calcul du code ASCII de la cl� / Calculation of the checksum ASCII code
    checksum = (checksum < 95) ? checksum + 32 : checksum + 105;
    //Ajout de la cl� et du STOP / Add the checksum and the STOP
    if (j < *SizeOut) *(BufOut + j) = checksum;
    j++;
    if (j < *SizeOut) *(BufOut + j) = 211;
    j++;
    if (j > *SizeOut) {
      *SizeOut = j;
      return -1;
    } else {
      *SizeOut = j;
      return 0;
    }
  } else {
	  return 1;
  }
}
